import json
import math
import re

import requests
import scrapy

from kick_starter.items import KSProjectItem, RewardItem
from kick_starter import settings

currency_cache = dict()


def parse_int(string):
	return int(''.join(filter(lambda x: x.isdigit(), string)))


class KickSpiderSpider(scrapy.Spider):  # TODO A better name would be much appreciated
	name = 'kick_spider'
	allowed_domains = ['kickstarter.com']
	url = 'https://www.kickstarter.com/discover/categories/technology?page={0}'

	def __init__(self, **kwargs):
		super().__init__(**kwargs)

		self.items_count = 0

	def start_requests(self):
		pages_limit = math.ceil(settings.ITEMS_LIMIT / 12)
		for i in range(pages_limit):
			yield scrapy.Request(url=self.url.format(i + 1), callback=self.parse)

	def parse(self, response):
		"""
		Parse projects cards and basic data from each page
		yield KSProjectItem
		"""
		if response.status != 200:
			"""Page did not load"""
			return

		cards = response.css('.js-react-proj-card')
		for card in cards:
			if self.items_count >= settings.ITEMS_LIMIT:
				return
			data = json.loads(card.attrib['data-project'])
			item = KSProjectItem()

			item['id'] = str(self.items_count)
			item['url'] = data['urls']['web']['project']
			item['currency'] = data['currency']
			item['Title'] = data['name']
			item['Creator'] = data['creator']['name']

			self.items_count += 1

			rewards_url = data['urls']['web']['rewards']
			request = scrapy.Request(
				url=item['url'], callback=self.parse_project,
				cb_kwargs=dict(item=item, currency=data['currency'], rewards_url=rewards_url))
			yield request

	def parse_project(self, response, item, currency, rewards_url):
		"""
		Parses project page
		updates given item
		"""
		if response.status != 200:
			"""Page did not load"""
			return
		info = response.xpath('//*[@id="react-project-header"]/div/div')[0]
		pledged = info.xpath('div[3]/div/div[2]/div[1]/div[2]/span/span/text()').get()
		goal: str = info.xpath('div[3]/div/div[2]/div[1]/span/span[1]/span/text()').get()

		pledged = parse_int(pledged)
		goal = parse_int(goal)
		item['DollarsPledged'] = self.convert_currency(currency, pledged)
		item['DollarsGoal'] = self.convert_currency(currency, goal)
		item['NumBackers'] = parse_int(info.xpath('div[1]/div[2]/div[2]/div[2]/div/span/text()').get())
		time = parse_int(info.xpath('div[1]/div[2]/div[2]/div[3]/div/div/span[1]/text()').get())
		time_type: str = info.xpath('div[1]/div[2]/div[2]/div[3]/div/div/span[2]/text()').get().lower()
		if time_type == 'minutes':
			time /= 1440  # minutes per day
		elif time_type == 'hours':
			time /= 24
		elif time_type == 'weeks':  # not sure if exists
			time *= 7
		elif time_type == 'years':  # is this even possible?
			time *= 360
		assert (time_type in ['days', 'hours', 'minutes'])
		item['DaysToGo'] = round(time, 3)
		links = response.css('.link-soft-black')
		item['AllOrNothing'] = len(links) > 0
		item['Text'] = response.xpath(
			'//*[@id="content-wrap"]/div[2]/section[1]/div/div/div/div[1]/div/div/div[1]').get()
		yield scrapy.Request(url=rewards_url, callback=self.parse_rewards, cb_kwargs=dict(item=item))

	def parse_rewards(self, response, item):
		"""
		Parses rewards from project page
		:return: RewardsItem
		"""
		if response.status != 200:
			"""Page did not load"""
			return
		rewards = []
		rewards_elem = response.css('.pledge__info')  # TODO please think of better names
		for reward_elem in rewards_elem:
			if reward_elem.css('.pledge__amount::text').get().strip() == 'Make a pledge without a reward':
				continue
			reward = RewardItem()
			reward['Text'] = reward_elem.css('.pledge__reward-description').get().strip()
			reward['Price'] = ''.join(filter(
				lambda x: x.isdigit(),
				reward_elem.css('.pledge__amount > .pledge__currency-conversion > span::text').get().strip()))
			backers: str = reward_elem.css('.pledge__backer-stats > span.pledge__backer-count::text').get().strip()
			backers_limit = reward_elem.css('div.pledge__backer-stats > span.pledge__limit::text').get()
			is_reward_gone = reward_elem.css(
				'div.pledge__backer-stats > span.pledge__limit--all-gone').get() is not None
			reward['NumBackers'] = int(re.findall(r'\d+', backers)[0])
			if backers_limit is not None and not is_reward_gone:
				backers_limit = backers_limit.strip()
				reward['TotalPossibleBackers'] = int(re.findall(r'\d+', backers_limit)[1])
			elif is_reward_gone:
				reward['TotalPossibleBackers'] = reward['NumBackers']

			rewards.append(reward)
		item['Rewards'] = rewards
		yield item

	def get_currency_rate(self, currency):
		if currency not in currency_cache:
			response = requests.get(
				url=f'https://free.currconv.com/api/v7/convert?q={currency}_USD&compact=ultra&apiKey=0c7e00b3efb1521d1200')
			if response.status_code == 200:
				data = json.loads(response.text)
				currency_cache[currency] = data[f'{currency}_USD']

			else:
				raise Exception("Could not get currency rates")
		return currency_cache[currency]

	def convert_currency(self, currency, amount):
		if currency == 'USD':
			return amount
		try:
			rate = self.get_currency_rate(currency)
		except:
			print("You WHAT???!!")
			return amount
		return int(amount * rate)
