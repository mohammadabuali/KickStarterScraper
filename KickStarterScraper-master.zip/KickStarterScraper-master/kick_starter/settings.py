# Scrapy settings for kick_starter scraper project

BOT_NAME = 'KickStarter'

SPIDER_MODULES = ['kick_starter.spiders']
NEWSPIDER_MODULE = 'kick_starter.spiders'

ITEMS_LIMIT = 1

ROBOTSTXT_OBEY = True

DOWNLOAD_DELAY = 1.5

FEED_EXPORT_INDENT = 4
FEED_STORE_EMPTY = True
FEED_FORMAT = "json"
FEED_URI = 'data/kickstarter.json'
FEED_OVERWRITE_FILE = True

FEED_EXPORTERS_BASE = {
	'json': 'kick_starter.exporters.CumulativeJsonExporter'
}

# Configure /docs.scrapy.org/en/latest/topics/item-pipeline.html
ITEM_PIPELINES = {
	'kick_starter.pipelines.ScreenshotsPipeline': 1,  # uncomment to take screenshots of visited projects
}
